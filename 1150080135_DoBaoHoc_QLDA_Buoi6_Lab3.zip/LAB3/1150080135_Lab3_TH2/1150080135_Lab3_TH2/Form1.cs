﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1150080135_Lab3_TH2
{
    public partial class Form1 : Form
    {
        private int selectedIndex = -1; // Track selected item for editing

        public Form1()
        {
            InitializeComponent();
            this.Text = "Đỗ Bảo Học_1150080135"; // Thêm tên vào title cửa sổ
        }

        // Nút Thêm - Add student information to ListView
        private void btnThem_Click(object sender, EventArgs e)
        {
            // Kiểm tra họ tên không được rỗng
            if (string.IsNullOrWhiteSpace(txtHoTen.Text))
            {
                MessageBox.Show("Họ tên sinh viên không được để trống!", "Thông báo", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtHoTen.Focus();
                return;
            }

            // Tạo item mới cho ListView
            ListViewItem item = new ListViewItem(txtHoTen.Text.Trim());
            item.SubItems.Add(dtpNgaySinh.Value.ToShortDateString());
            item.SubItems.Add(txtLop.Text.Trim());
            item.SubItems.Add(txtDiaChi.Text.Trim());

            // Thêm vào ListView
            lvSinhVien.Items.Add(item);

            // Xóa các ô nhập liệu sau khi thêm
            ClearInputFields();

            MessageBox.Show("Thêm sinh viên thành công!", "Thông báo", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Nút Sửa - Update selected student information
        private void btnSua_Click(object sender, EventArgs e)
        {
            // Kiểm tra có item nào được chọn không
            if (lvSinhVien.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn một sinh viên để sửa!", "Thông báo", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Kiểm tra họ tên không được rỗng
            if (string.IsNullOrWhiteSpace(txtHoTen.Text))
            {
                MessageBox.Show("Họ tên sinh viên không được để trống!", "Thông báo", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtHoTen.Focus();
                return;
            }

            // Cập nhật thông tin
            ListViewItem selectedItem = lvSinhVien.SelectedItems[0];
            selectedItem.Text = txtHoTen.Text.Trim();
            selectedItem.SubItems[1].Text = dtpNgaySinh.Value.ToShortDateString();
            selectedItem.SubItems[2].Text = txtLop.Text.Trim();
            selectedItem.SubItems[3].Text = txtDiaChi.Text.Trim();

            // Xóa các ô nhập liệu sau khi sửa
            ClearInputFields();

            MessageBox.Show("Cập nhật thông tin sinh viên thành công!", "Thông báo", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Nút Xóa - Delete selected student
        private void btnXoa_Click(object sender, EventArgs e)
        {
            // Kiểm tra có item nào được chọn không
            if (lvSinhVien.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn một sinh viên để xóa!", "Thông báo", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Xác nhận xóa
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa sinh viên này?", 
                "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                // Xóa item được chọn
                lvSinhVien.Items.Remove(lvSinhVien.SelectedItems[0]);
                
                // Xóa các ô nhập liệu
                ClearInputFields();

                MessageBox.Show("Xóa sinh viên thành công!", "Thông báo", 
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Nút Thoát - Exit application
        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn thoát?", 
                "Xác nhận thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        // Event when selecting an item in ListView
        private void lvSinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvSinhVien.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = lvSinhVien.SelectedItems[0];
                
                // Hiển thị thông tin của item được chọn lên các ô nhập liệu
                txtHoTen.Text = selectedItem.Text;
                
                // Parse ngày sinh
                if (DateTime.TryParse(selectedItem.SubItems[1].Text, out DateTime ngaySinh))
                {
                    dtpNgaySinh.Value = ngaySinh;
                }
                
                txtLop.Text = selectedItem.SubItems[2].Text;
                txtDiaChi.Text = selectedItem.SubItems[3].Text;

                selectedIndex = selectedItem.Index;
            }
        }

        // Method to clear all input fields
        private void ClearInputFields()
        {
            txtHoTen.Clear();
            txtLop.Clear();
            txtDiaChi.Clear();
            dtpNgaySinh.Value = DateTime.Now;
            selectedIndex = -1;
            
            // Clear selection in ListView
            lvSinhVien.SelectedItems.Clear();
            
            // Focus on first textbox
            txtHoTen.Focus();
        }
    }
}
